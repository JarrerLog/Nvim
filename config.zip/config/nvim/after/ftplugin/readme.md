## LSPConfig

This file contains presets for each coding language.
