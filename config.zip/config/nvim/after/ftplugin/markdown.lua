vim.wo.conceallevel = 2
vim.b.table_mode_corner = "|"
