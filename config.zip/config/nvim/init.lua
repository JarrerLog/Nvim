require("core")
require("pack").setup()
